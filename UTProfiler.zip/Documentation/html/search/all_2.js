var searchData=
[
  ['deleteallformations',['deleteAllFormations',['../classformation_manager.html#a67ac05471339dee7a55b46d06f2f2712',1,'formationManager']]],
  ['deletealluv',['deleteAllUV',['../class_u_v_manager.html#a95333fbf72dee3874c2e6492969dbfac',1,'UVManager']]],
  ['deleteformation',['deleteFormation',['../classformation_manager.html#adb0d5630c330c55dee53e034e1258d56',1,'formationManager']]],
  ['deleteuv',['deleteUV',['../class_u_v_manager.html#ab1f7e555b456dd2d34907061f65b1405',1,'UVManager']]]
];
